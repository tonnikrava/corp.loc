<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use TCG\Voyager\Models\Page;

class MainController extends Controller
{
    public function getIndex() {

        echo view('index');
    }
    public function spets($page) {
        $content = Page::where('slug', '=', $page)->get();
        dump($content);
        echo view('spets');
    }
}


